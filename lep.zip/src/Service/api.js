import axios from 'axios'

export default axios.create({
    baseURL:'http://admin.liveexamcenter.in/api/'
})